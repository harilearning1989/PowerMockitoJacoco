package com.web.emp.exception;

public class ResourceNotFoundException extends Exception{
}
