package com.web.emp.utils;

public class EmployeeUtils {
    public static String getInitials(String empName, String fatherName) {
        return empName + fatherName;
    }

    public static String sendEmail(){
        return "Success";
    }
}
