package com.web.emp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeApplication {

	//http://localhost:8081/swagger-ui/index.html
	public static void main(String[] args) {
		SpringApplication.run(EmployeeApplication.class, args);
	}

	//https://github.com/pkainulainen/spring-mvc-test-examples/blob/master/rest/src/test/java/net/petrikainulainen/spring/testmvc/todo/service/RepositoryTodoServiceTest.java
	//https://codefiction.net/unit-testing-crud-endpoints-of-a-spring-boot-java-web-service-api/

	/*https://www.youtube.com/watch?v=myW9bh9iSm4
	https://www.youtube.com/watch?v=3IbdOGahtk8&t=5s
	https://www.youtube.com/watch?v=Enw4v6SuvSs


	//https://java2blog.com/powermock-tutorial/

	/*CREATE TABLE IF NOT EXISTS `test`.`user` (
			`username` VARCHAR(45) NOT NULL,
  `firstname` VARCHAR(45) NOT NULL,
  `description` VARCHAR(45) NOT NULL,
	PRIMARY KEY (`username`, `firstname`))

	@Embeddable
	public class UserKey implements Serializable {
		protected String username;
		protected String firstname;

		public UserKey() {}

		public UserKey(String username, String firstname) {
			this.username = username;
			this.firstname = firstname;
		}
	}

	@Entity
	public class UserEntity implements Serializable {
		@EmbeddedId
		private UserKey primaryKey;
		private String description;
	}

	public interface UserEntityRepository extends JpaRepository<UserEntity, UserKey>*/

}
