package com.web.emp.mock;

public class ClassWithStaticMethod {

    public static String printMessage(String message) {
        return message;
    }

}
