package com.web.emp.mock;

public class ClassWithFinalMethods {

    public final String printMessage(String message) {
        return message;
    }
}
