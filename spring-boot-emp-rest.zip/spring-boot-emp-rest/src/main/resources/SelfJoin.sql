SELECT e1.emp_id emp_id, e1.emp_name emp_name,
       e2.emp_id manager_id, e2.emp_name AS manager_name
FROM   sys.employee e1, sys.employee e2
       where e1.manager_id  = e2.emp_id order by emp_id;